package com.example.g2s21_ddim_practica1_armm;

import android.app.Activity;
import android.content.Context;

import java.io.IOException;
import java.io.OutputStreamWriter;

public class almacen {
    public boolean grabar(String nombre, int edad, String correo, Context context){
        boolean estado = true;
        try (OutputStreamWriter archivo = new OutputStreamWriter(context.openFileOutput("datos.txt", Activity.MODE_PRIVATE))) {
            archivo.write(nombre);
            archivo.write(String.valueOf(edad));
            archivo.write(correo);
            archivo.flush();
        } catch (IOException ex) {
            estado = false;

        }
        return estado;
    }
}