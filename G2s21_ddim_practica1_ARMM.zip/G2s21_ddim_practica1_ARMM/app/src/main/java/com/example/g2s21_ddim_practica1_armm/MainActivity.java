package com.example.g2s21_ddim_practica1_armm;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText txtnombre, txtedad, txtcorreo;
    Button btngrabar, btnsalir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar los elementos
        txtnombre = findViewById(R.id.txtnombre);
        txtedad = findViewById(R.id.txtedad);
        txtcorreo = findViewById(R.id.txtcorreo);
        btngrabar = findViewById(R.id.btngrabar);
        btnsalir = findViewById(R.id.btnsalir);

        // boton de salida
        btnsalir.setOnClickListener(v -> finish());

        // Set listener for the save button
        btngrabar.setOnClickListener(v -> {
            almacen Almacen = new almacen();
            if (Almacen.grabar(txtnombre.getText().toString(),Integer.parseInt(txtedad.getText().toString()),txtcorreo.getText().toString(),this)) {
                Toast.makeText(this,"se grabo correctamente",Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this,"NO se grabo correctamente",Toast.LENGTH_SHORT).show();
            }
        });
    }
}